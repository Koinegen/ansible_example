!#/bin/bash
apt install sl -y